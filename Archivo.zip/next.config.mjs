/** @type {import('next').NextConfig} */
const nextConfig = {images: {
    domains: ['www.cruzeirogomas.cl'], // Agrega el dominio aquí
  },};


export default nextConfig;
