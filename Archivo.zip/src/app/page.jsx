import Checkout from './components/Checkout';

export default function CheckoutPage() {
  return (
    <main className="min-h-screen bg-background" Style="height:100vh;">
      <Checkout />
    </main>
  );
}

